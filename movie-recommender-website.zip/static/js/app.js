class MovieRecommender {
    constructor() {
        this.movieSelect = document.getElementById('movieSelect');
        this.recommendBtn = document.getElementById('recommendBtn');
        this.loadingSpinner = document.getElementById('loadingSpinner');
        this.errorAlert = document.getElementById('errorAlert');
        this.errorMessage = document.getElementById('errorMessage');
        this.recommendationsSection = document.getElementById('recommendationsSection');
        this.selectedMovieText = document.getElementById('selectedMovieText');
        
        this.init();
    }

    async init() {
        await this.loadMovies();
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.recommendBtn.addEventListener('click', () => this.getRecommendations());
        
        this.movieSelect.addEventListener('change', () => {
            this.recommendBtn.disabled = !this.movieSelect.value;
            this.hideRecommendations();
        });
    }

    async loadMovies() {
        try {
            this.showLoading(true);
            const response = await fetch('/api/movies');
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Failed to load movies');
            }

            this.populateMovieSelect(data.movies);
            
        } catch (error) {
            console.error('Error loading movies:', error);
            this.showError(`Failed to load movie list: ${error.message}`);
        } finally {
            this.showLoading(false);
        }
    }

    populateMovieSelect(movies) {
        // Clear existing options
        this.movieSelect.innerHTML = '<option value="">Select a movie...</option>';
        
        // Add movie options
        movies.forEach(movie => {
            const option = document.createElement('option');
            option.value = movie;
            option.textContent = movie;
            this.movieSelect.appendChild(option);
        });

        // Enable the select
        this.movieSelect.disabled = false;
    }

    async getRecommendations() {
        const selectedMovie = this.movieSelect.value;
        
        if (!selectedMovie) {
            this.showError('Please select a movie first');
            return;
        }

        try {
            this.showLoading(true);
            this.hideError();
            this.hideRecommendations();
            this.recommendBtn.disabled = true;

            const response = await fetch('/api/recommend', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ movie: selectedMovie })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Failed to get recommendations');
            }

            this.displayRecommendations(data);
            
        } catch (error) {
            console.error('Error getting recommendations:', error);
            this.showError(`Failed to get recommendations: ${error.message}`);
        } finally {
            this.showLoading(false);
            this.recommendBtn.disabled = false;
        }
    }

    displayRecommendations(data) {
        // Update selected movie text
        this.selectedMovieText.textContent = `Based on your selection: "${data.selected_movie}"`;

        // Update recommendation cards with enhanced visuals
        data.recommendations.forEach((recommendation, index) => {
            const movieElement = document.getElementById(`movie-${index}`);
            const scoreElement = document.getElementById(`score-${index}`);
            const posterElement = document.getElementById(`poster-${index}`);
            const starsElement = document.getElementById(`stars-${index}`);
            
            if (movieElement && scoreElement && posterElement && starsElement) {
                movieElement.textContent = recommendation.title;
                scoreElement.textContent = `${(recommendation.similarity_score * 100).toFixed(1)}%`;
                
                // Generate movie poster
                this.generateMoviePoster(posterElement, recommendation.title);
                
                // Generate rating stars based on similarity score
                this.generateRatingStars(starsElement, recommendation.similarity_score);
                
                // Add staggered animation
                const card = movieElement.closest('.recommendation-card');
                if (card) {
                    card.style.animationDelay = `${index * 0.1}s`;
                    card.classList.add('animate-in');
                }
            }
        });

        // Show recommendations section with 3D animation
        this.recommendationsSection.style.display = 'block';
        this.recommendationsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
        // Add entrance animation
        setTimeout(() => {
            this.recommendationsSection.classList.add('section-visible');
        }, 100);
    }

    generateMoviePoster(posterElement, movieTitle) {
        // Create a visually appealing poster with the movie title
        const colors = [
            ['#667eea', '#764ba2'], ['#f093fb', '#f5576c'], ['#4facfe', '#00f2fe'],
            ['#43e97b', '#38f9d7'], ['#fa709a', '#fee140'], ['#a8edea', '#fed6e3'],
            ['#ffecd2', '#fcb69f'], ['#ff9a9e', '#fecfef'], ['#a18cd1', '#fbc2eb'],
            ['#fad0c4', '#ffd1ff']
        ];
        
        const colorPair = colors[Math.abs(this.hashCode(movieTitle)) % colors.length];
        
        posterElement.innerHTML = `
            <div class="movie-poster-content" style="
                background: linear-gradient(135deg, ${colorPair[0]} 0%, ${colorPair[1]} 100%);
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 15px;
                text-align: center;
                position: relative;
                overflow: hidden;
            ">
                <div style="
                    position: absolute;
                    top: -50%;
                    left: -50%;
                    width: 200%;
                    height: 200%;
                    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
                    animation: posterGlow 4s ease-in-out infinite alternate;
                "></div>
                <i class="fas fa-film fa-2x text-white mb-2 opacity-75" style="z-index: 1;"></i>
                <div style="
                    font-size: 0.8rem;
                    font-weight: bold;
                    text-shadow: 0 2px 4px rgba(0,0,0,0.5);
                    color: white;
                    line-height: 1.2;
                    z-index: 1;
                    max-height: 60px;
                    overflow: hidden;
                    display: -webkit-box;
                    -webkit-line-clamp: 3;
                    -webkit-box-orient: vertical;
                ">${movieTitle}</div>
            </div>
        `;
    }

    generateRatingStars(starsElement, similarity) {
        const rating = Math.ceil(similarity * 5); // Convert to 1-5 stars
        let starsHtml = '';
        
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                starsHtml += '<i class="fas fa-star text-warning"></i>';
            } else {
                starsHtml += '<i class="far fa-star text-muted"></i>';
            }
        }
        
        starsElement.innerHTML = starsHtml;
    }

    hashCode(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash;
    }

    showLoading(show) {
        this.loadingSpinner.style.display = show ? 'block' : 'none';
    }

    showError(message) {
        this.errorMessage.textContent = message;
        this.errorAlert.style.display = 'block';
        this.errorAlert.scrollIntoView({ behavior: 'smooth' });
    }

    hideError() {
        this.errorAlert.style.display = 'none';
    }

    hideRecommendations() {
        this.recommendationsSection.style.display = 'none';
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new MovieRecommender();
});

// Health check function for debugging
async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        console.log('Health Status:', data);
        return data;
    } catch (error) {
        console.error('Health check failed:', error);
        return null;
    }
}

// Expose health check globally for debugging
window.checkHealth = checkHealth;
